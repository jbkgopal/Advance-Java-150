package com.hrushi.configuration;

import java.sql.Connection;
import java.sql.DriverManager;

public class Configuration {
		
	public static  Connection config() {
		
		Connection connect=null;
		
		String user="jdbc:mysql://localhost:3306/hrushi_db"; //hrushi_db schema name/database name
		String id="root";
		String password="root";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); //Driver connection. Mysql 8.1 version
			
			connect=DriverManager.getConnection(user, id, password); //Connection to database
			
			
			
		} catch (Exception e) {
			System.out.println("Failed to connect to the database hrushi_db 🥲 ");
		}
		return connect;
	}

}
