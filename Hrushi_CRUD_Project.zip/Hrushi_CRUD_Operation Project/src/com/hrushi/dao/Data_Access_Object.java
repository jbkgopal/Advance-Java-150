package com.hrushi.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.hrushi.configuration.*;

public class Data_Access_Object {

	public void getrecord() throws Exception {

		try {
			Connection connect = Configuration.config();
			// To perform multiple queries at a time
			PreparedStatement ps = connect.prepareStatement("SELECT * FROM employee");
			// used to iterate through each row from start to end
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) { // .next it moves cursor one row forward from its current position

				int id = rs.getInt(1);// Retrieves the value of the designated column in the current row of this
										// ResultSet object
				String name = rs.getString(2);// Retrieve string value from column no 2

				System.out.println(id + " " + name);

			}
			System.out.println("\n");
		} catch (Exception e) {

			System.out.println("Data Not Found. 😐");
		}

	}

	public void insertrecord() throws Exception {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id you want to insert in table  : \n");
		int id = sc.nextInt();

		System.out.println("Enter the name you want to insert in table : \n");
		String name = sc.next();

		Connection connect = Configuration.config();

		PreparedStatement ps = connect.prepareStatement("INSERT INTO employee VALUES (?,?)");

		ps.setInt(1, id);
		ps.setString(2, name);
		ps.executeUpdate();
		System.out.println("Data Inserted Successfully. 🥳\n");
	}

	public void updaterecord() throws Exception {
		Connection connect = Configuration.config();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id where you want to update data of table : \n");
		int id = sc.nextInt();

		System.out.println("Enter the name you want to in your table : \n");
		String name = sc.next();

		PreparedStatement ps = connect.prepareStatement("UPDATE employee SET name=? WHERE id=?");

		ps.setInt(2, id);
		ps.setString(1, name);
		ps.executeUpdate();
		System.out.println("Data Updated Successfully. 😁\n");

	}

	public void deleterecord() throws Exception {
		Connection connect = Configuration.config();

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id which data you want to delete : \n");
		int id = sc.nextInt();

		PreparedStatement ps = connect.prepareStatement("DELETE FROM employee WHERE id=?");

		ps.setInt(1, id);
		ps.executeUpdate();
	}

}
