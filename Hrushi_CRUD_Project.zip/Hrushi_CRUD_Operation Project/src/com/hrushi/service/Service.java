package com.hrushi.service;

import java.util.Scanner;

import com.hrushi.dao.Data_Access_Object;

public class Service {

	public void do_operation() throws Exception {
		Data_Access_Object dao = new Data_Access_Object();

		dao.getrecord();

		System.out.println("     **********    Operation to be Performed     **********\n");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the operation number you want to perform.\n");

		System.out.println("1. To insert the data in Table. ✒️✒️✒️ \n ");
		System.out.println("2. To Update the data of Table. 📲📲📲 \n ");
		System.out.println("3. To Delete the data from Table. ❌❌❌ \n ");
		System.out.println("4. To Exit the Operation on Table 📤📤📤 \n");
		System.out.println("                                 ❤️Code written by Hrushi Pawar❤️\n");
		System.out.println("                          ********************\n");

		int number;

		do {
			System.out.println("Enter your choice : ");
			number = sc.nextInt();

			if (number == 1) {
				dao.insertrecord();

				System.out.println("\nData table of database hrushi_db after Insertion of data : \n");

				dao.getrecord();

			}

			if (number == 2) {
				dao.updaterecord();

				System.out.println("\nData table of database hrushi_db after Updatation of data : \n");

				dao.getrecord();

			}
			if (number == 3) {
				dao.deleterecord();

				System.out.println("\nData table of database hrushi_db after Deletion of data : \n");

				dao.getrecord();

			}
			if (number >= 5 || number <= 0) {
				System.out.println("Envalid Choice 💀💀💀💀💀");

			}

		} while (number != 4);

		System.out.println("\nOperation Successfully Exited. 🥱🥱🥱");

	}

}
