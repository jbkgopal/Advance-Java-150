package com.hrushi.controller;

import com.hrushi.service.*;

public class Controller {
	
	public static void main(String[] args) throws Exception {
		Service ser=new Service();
		ser.do_operation();
	}

}
