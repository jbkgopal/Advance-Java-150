package com.Gopal.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

// Data Base Connection Code
public class StudentDAO {

	public String insert;
	public String update;
	public String delete;
	public String select;

	public void insertD() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		insert = "insert into student values(1,'Gopal')";
		Statement s = c.createStatement();
		s.executeUpdate(insert);
		System.out.println("ggggg");
	}

	public void insertP(int id, String name) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		insert = "insert into student values(?,?)";
		PreparedStatement s = c.prepareStatement(insert);
		s.setInt(1, id);
		s.setString(2, name);
		s.executeUpdate();
		System.out.println("ggggg");
	}

	public void update() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		update = "update student set name='Raja' where id=1";
		Statement s = c.createStatement();
		s.executeUpdate(update);

	}

	public void delete() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		delete = "delete from student where id=1";
		Statement s = c.createStatement();
		s.executeUpdate(delete);

	}

	public void select() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		select = "select * from student";
		Statement s = c.createStatement();
		ResultSet r = s.executeQuery(select);
		while (r.next()) {
			System.out.println(r.getInt(1) + " " + r.getString(2));
		}

	}
}
