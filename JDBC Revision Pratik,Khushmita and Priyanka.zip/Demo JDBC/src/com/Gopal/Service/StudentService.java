package com.Gopal.Service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.Gopal.DAO.StudentDAO;

// Business Logic
public class StudentService {

	public void insertD() throws Exception {
		StudentDAO sd = new StudentDAO();
		sd.insertD();
	}
	
	
	public void insertP(int id, String name) throws Exception {
		StudentDAO sd = new StudentDAO();
		sd.insertP(id,name);
	}

	public void update() throws Exception {
		StudentDAO sd = new StudentDAO();
		sd.update();
	}

	public void delete() throws Exception {
		StudentDAO sd = new StudentDAO();
		sd.delete();
	}

	public void select() throws Exception {
		StudentDAO sd = new StudentDAO();
		sd.select();
	}

}
