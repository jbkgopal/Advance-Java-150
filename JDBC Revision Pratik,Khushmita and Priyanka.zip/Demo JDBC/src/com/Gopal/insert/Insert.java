package com.Gopal.insert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Insert {

	public String insert;

	public void insert() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		String insert = "insert into student values(1,'Gopal')";
		Statement s = c.createStatement();
		s.executeUpdate(insert);
		System.out.println("ggggg");
	}

}
