package com.Gopal.select;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Select {

	String select;

	public void select() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		select = "select * from student";
		Statement s = c.createStatement();
		ResultSet r = s.executeQuery(select);
		while (r.next()) {
			System.out.println(r.getInt(1) + " " + r.getString(2));
		}
	
	}
}
