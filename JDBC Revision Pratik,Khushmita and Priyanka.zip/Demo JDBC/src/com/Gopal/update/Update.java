package com.Gopal.update;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Update {

	String update;

	public void update() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		update = "update student set name='Raja' where id=1";
		Statement s = c.createStatement();
		s.executeUpdate(update);
	
	}
}
