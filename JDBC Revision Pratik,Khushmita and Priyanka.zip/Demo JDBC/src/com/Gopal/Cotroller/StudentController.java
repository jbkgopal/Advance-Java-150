package com.Gopal.Cotroller;

import com.Gopal.Service.StudentService;

// Controller to control the Service and DAO main 
public class StudentController {

	public static void main(String[] args) throws Exception {
		StudentService ss = new StudentService();
		ss.insertD();
		ss.insertP(101, "GGGG");
		ss.update();
		ss.delete();
		ss.select();
	}
}
