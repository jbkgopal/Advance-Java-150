package com.Gopal.delete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Delete {

	String delete;

	public void delete() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3737/batch150", "root", "root");

		// Logic 1
		delete = "delete from student where id=1";
		Statement s = c.createStatement();
		s.executeUpdate(delete);

		
	}
}
