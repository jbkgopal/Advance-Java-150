package Sbi_Bank;

public class Test {

	public static void main(String[] args) throws Exception {

		JDBCAdd t = new JDBCAdd();
		t.Bank();
	}
}
