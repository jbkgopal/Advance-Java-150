package Sbi_Bank;

public class Variables {

	private String Accountname = "Shubham";
	private int Accountno = 12345;
	private static int Accountbalance = 50000;
	
	public String getAccountname() {
		return Accountname;
	}

	public void setAccountname(String accountname) {
		Accountname = accountname;
	}

	public int getAccountno() {
		return Accountno;
	}

	public void setAccountno(int accountno) {
		Accountno = accountno;
	}

	public int getAccountbalance() {
		return Accountbalance;
	}

	public void setAccountbalance(int accountbalance) {
		Accountbalance = accountbalance;
	}

	@Override
	public String toString() {
		return "Variables [Accountname=" + Accountname + ", Accountno=" + Accountno + ", Accountbalance="
				+ Accountbalance + "]";
	}
	
}
