package Sbi_Bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class JDBCAdd {
	
	public void select() throws Exception {

		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/sbi_bank", "root", "root");

		PreparedStatement s = c.prepareStatement("select * from transition");

		ResultSet r = s.executeQuery();
		System.out.println("Tranisition History");
		System.out.println();
		while (r.next()) {
			System.out.println("T.No" + r.getInt(1) + " " + "Deposit" + r.getInt(2) + " " + "Withdraw" + r.getInt(3));
		}
	}

	public void Bank() throws Exception {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to Sbi bank.............");
		System.out.println("Enter your account number 🤷‍♀️🤷‍");
		int Accountnumber = sc.nextInt();
		System.out.println("Enter your pin");
		
		int Accountpin = sc.nextInt();
		Variables v = new Variables();
		v.getAccountname();
		v.getAccountno();
		v.getAccountbalance();
		if(Accountnumber == v.getAccountno() && Accountpin == 12345) {
			System.out.println("Welcome " + v.getAccountname());
			System.out.println("\n1.Balance Enquiry\n2.Deposit Cash\n3.Withdraw Cash\n4.Transitions");
			int p = sc.nextInt();
		
//			aa.insert(p);
			Deposit d = new Deposit();
			Withdrawal ww = new Withdrawal();
			switch(p) {
			case 1:
				System.out.println(v.getAccountbalance() + "/- only");
				break;
			case 2:
				d.main(null);
				break;
			case 3:
				ww.main(null);
				break;
			case 4:
				select();
				break;
				default :
					System.out.println("Enter valid number");
					break;
				}
			
		}else {
			System.out.println("You Have Entered Wrong Account Details..........!");
		}
	}
}
