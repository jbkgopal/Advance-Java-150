package Sbi_Bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Withdrawal {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Amount To Withdraw........");
		int Amount = sc.nextInt();
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/sbi_bank", "root", "root");
		PreparedStatement s = c.prepareStatement("insert into transition values (2,0,?)");

		Variables v = new Variables();
		v.getAccountbalance();
		if (Amount >= 0) {
			s.setInt(1, Amount);
			s.executeUpdate();
			int a = v.getAccountbalance() - Amount;
			v.setAccountbalance(Amount);
			System.out.println("Transision Complete.............");
			System.out.println(v);
		} else {
			System.out.println("This Amount Is Not A Valid Amount.......");
		}

	}
}
