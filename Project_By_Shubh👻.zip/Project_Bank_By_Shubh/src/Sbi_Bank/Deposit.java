package Sbi_Bank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Deposit {
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println(" Enter Amount To Be Added");
		int amount = sc.nextInt();
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/sbi_bank", "root", "root");
		PreparedStatement s = c.prepareStatement("insert into transition values(1,?,0)");
		
		
		Variables v = new Variables();
		
		if (amount > 0) {
			s.setInt(1, amount);
			s.executeUpdate();
			int a = v.getAccountbalance()+amount;
			v.setAccountbalance(a);
			System.out.println("Amount Deposited Successfully...............");
			System.out.println(v);
		} else {
			System.out.println("Enter The Valid Amount............");
		}
	}
}
