import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmployeeController {

	public static void main(String[] args) {
		Configuration cfg=new Configuration();
		cfg.addAnnotatedClass(Employee.class).configure();
		SessionFactory sf=cfg.buildSessionFactory();
		Session ss=sf.openSession();
		Transaction t=ss.beginTransaction();//I/U/D
		Employee ee=new Employee(102, "Java");
		//ss.save(ee); // add/insert/save
		//ss.update(ee);
		ss.delete(ee);
		System.out.println("Insert Record..."+ee);
		
		t.commit();
		ss.close();
	}
}
