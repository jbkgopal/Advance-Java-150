package com.hrushi.dao;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hrushi.connect.Connect;
import com.hrushi.entity.Employee;

import antlr.collections.List;

public class Data_Access_Object {

	Session ss = Connect.connection();

	Transaction t = ss.beginTransaction();

	public void insert() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the id  you want to insert ✒️✒️✒️ : \n");

		int id = sc.nextInt();

		System.out.println("Enter the name you want to insert ✒️✒️✒️ : \n");

		String name = sc.next();

		System.out.println("Enter the age you want to insert ✒️✒️✒️ : \n");

		int age = sc.nextInt();

		Employee ee = new Employee(id, name, age);

		ss.save(ee);

		t.commit();

		ss.close();
	}

	public void update() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the id that you want to change 📲📲📲 : ");

		int id = sc.nextInt();

		System.out.println("Enter the updated name for the id 📲📲📲 : " + id + " : ");

		String name = sc.next();

		System.out.println("Enter the age for 📲📲📲 " + name + " : ");

		int age = sc.nextInt();

		Employee ee = new Employee(id, name, age);

		ss.update(ee);

		t.commit();

		ss.close();
	}

	public void delete() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the id that you want to change 📲📲📲 : ");

		int id = sc.nextInt();


		Employee ee = new Employee(id);

		ss.delete(ee);

		t.commit();

		ss.close();
	}

	

}
