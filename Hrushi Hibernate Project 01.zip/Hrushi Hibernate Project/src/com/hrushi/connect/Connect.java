package com.hrushi.connect;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hrushi.entity.Employee;


public class Connect {
	
	public static Session connection() {
		
		Configuration cfg=new Configuration();
		
		cfg.addAnnotatedClass(Employee.class).configure("hrushi.xml");
		
		SessionFactory sf=cfg.buildSessionFactory();
		
		Session ss=sf.openSession();
		
		return ss;
	}

}
