package com.hrushi.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
//to connect with table
@Entity
public class Employee {
	@Id
	private int id;
	private String name;
	private int age;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int id) {
		super();
		this.id = id;
	}
	
	
	public Employee(int id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	
	

}
