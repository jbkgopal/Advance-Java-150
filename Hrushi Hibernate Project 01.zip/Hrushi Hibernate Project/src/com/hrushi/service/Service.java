package com.hrushi.service;

public interface Service {
	
	public void insert();
	
	public void update();
	
	public void delete();

}
