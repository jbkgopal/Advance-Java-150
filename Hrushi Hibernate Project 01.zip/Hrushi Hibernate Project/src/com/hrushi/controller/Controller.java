package com.hrushi.controller;

import java.util.Scanner;

import com.hrushi.service_implement.Service_implement;

public class Controller extends Service_implement{
	
	public void option() {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Press 1 ☝️☝️☝️ to INSERT NEW DATA  \nPress 2 ✌️✌️✌️ to UPDATE THE EXIXTING DATA\nPress 3 to DELETE ROW 😵😵😵\nPress 4 👌👌👌 to EXIT THE PROCESS❌❌❌ ");
		
		int number;
		
		do {	
			
			System.out.println("\nEnter Your Choice : ");
			number=sc.nextInt();
			
			if(number ==1) {
				Controller cc=new Controller();
				cc.insert();
			}		
			if(number ==2) {
				Controller cc=new Controller();
				cc.update();
			}
			if(number==3) {
				Controller cc=new Controller();
				cc.delete();
			}
			if(number>=5 || number<1) {
				System.out.println("INVALID CHOICE 💀💀💀💀");
			}
						
		} while (number !=4);
		
		System.out.println("Operation Executed Successfully and EXITED 🥱🥱🥱");
			
	}
	public static void main(String[] args) {
		Controller cc=new Controller();
		cc.option();

}
}