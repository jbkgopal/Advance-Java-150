package com.hrushi.service_implement;

import com.hrushi.dao.Data_Access_Object;
import com.hrushi.service.Service;

public class Service_implement implements Service {

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		Data_Access_Object dao=new Data_Access_Object();
		
		dao.insert();
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		Data_Access_Object dao=new Data_Access_Object();
		
		dao.update();
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		
		Data_Access_Object dao=new Data_Access_Object();
		
		dao.delete();
	}
	
	

}
